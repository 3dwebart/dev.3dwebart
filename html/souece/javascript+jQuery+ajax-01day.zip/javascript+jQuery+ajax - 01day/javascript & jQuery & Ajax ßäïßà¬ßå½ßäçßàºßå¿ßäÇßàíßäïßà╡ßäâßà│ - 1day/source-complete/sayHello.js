alert("안녕하세요~ Javascript");
